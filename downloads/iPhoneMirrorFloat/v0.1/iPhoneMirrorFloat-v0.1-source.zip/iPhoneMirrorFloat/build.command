#!/bin/zsh
set -e
cd "$(dirname "$0")"
APP="$PWD/build/iPhone镜像悬浮助手.app"
mkdir -p "$APP/Contents/MacOS"
/usr/bin/swiftc -O -framework AppKit -framework SwiftUI -framework ApplicationServices -framework CoreGraphics \
  Sources/MirrorFloat/main.swift -o "$APP/Contents/MacOS/MirrorFloat"
cp Info.plist "$APP/Contents/Info.plist"
/usr/bin/codesign --force --deep --sign - "$APP"
echo "构建成功: $APP"
open "$APP"
