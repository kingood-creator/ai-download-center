import AppKit
import SwiftUI
import ApplicationServices
import CoreGraphics

enum FloatMode: String { case attached, detached }

final class MirrorService: ObservableObject {
    static let shared = MirrorService()
    @Published var mode: FloatMode = UserDefaults.standard.string(forKey: "mode").flatMap(FloatMode.init(rawValue:)) ?? .attached
    @Published var expanded = false
    @Published var message = "准备就绪"
    @Published var permissionGranted = AXIsProcessTrusted()
    @Published var launchAtLogin = false
    weak var panel: NSPanel?
    private var tracker: Timer?
    private var lastTrackedFrame: CGRect?

    init() {
        tracker = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.permissionGranted = AXIsProcessTrusted()
            self?.trackMirror()
        }
    }

    func requestPermission() {
        let opts: NSDictionary = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true]
        _ = AXIsProcessTrustedWithOptions(opts)
        permissionGranted = AXIsProcessTrusted()
    }

    func changeMode() {
        mode = mode == .attached ? .detached : .attached
        UserDefaults.standard.set(mode.rawValue, forKey: "mode")
        message = mode == .attached ? "跟随镜像窗口" : "独立悬浮模式"
        if mode == .attached { trackMirror(force: true) }
        else if let p = panel {
            let x = UserDefaults.standard.object(forKey: "detachedX") as? Double
            let y = UserDefaults.standard.object(forKey: "detachedY") as? Double
            if let x, let y { p.setFrameOrigin(NSPoint(x:x, y:y)) }
        }
    }

    func setExpanded(_ value: Bool) {
        expanded = value
        guard let panel else { return }
        let origin = panel.frame.origin
        let size = NSSize(width: value ? 192 : 54, height: value ? 358 : 54)
        panel.setFrame(NSRect(origin: origin, size: size), display: true, animate: true)
        if mode == .attached { trackMirror(force: true) }
    }

    func bringForward() {
        guard let app = mirrorApp() else { message = "请先打开 iPhone 镜像"; return }
        app.activate(options: [.activateIgnoringOtherApps])
        message = "镜像已置前"
    }

    func send(_ key: CGKeyCode, shift: Bool = false) {
        guard permissionGranted else { message = "请先授权辅助功能"; requestPermission(); return }
        guard let app = mirrorApp() else { message = "请先打开 iPhone 镜像"; return }
        app.activate(options: [.activateIgnoringOtherApps])
        message = "已发送快捷键"
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
            guard let down = CGEvent(keyboardEventSource: nil, virtualKey: key, keyDown: true),
                  let up = CGEvent(keyboardEventSource: nil, virtualKey: key, keyDown: false) else { return }
            let flags: CGEventFlags = shift ? [.maskCommand, .maskShift] : [.maskCommand]
            down.flags = flags; up.flags = flags
            down.post(tap: .cghidEventTap)
            up.post(tap: .cghidEventTap)
        }
    }

    // macOS hardware virtual key codes: 1=18, 2=19, 3=20, 0=29, '='=24, '-'=27
    func home() { send(18) }
    func switcher() { send(19) }
    func spotlight() { send(20) }
    func bigger() { send(24, shift: true) }
    func smaller() { send(27) }
    func actualSize() { send(29) }

    private func mirrorApp() -> NSRunningApplication? {
        NSWorkspace.shared.runningApplications.first {
            let id = ($0.bundleIdentifier ?? "").lowercased()
            let name = ($0.localizedName ?? "").lowercased()
            return id.contains("iphonemirroring") || name.contains("iphone mirroring") || name.contains("iphone 镜像") || name.contains("iphone鏡像")
        }
    }

    private func mirrorFrame() -> CGRect? {
        guard let pid = mirrorApp()?.processIdentifier,
              let windows = CGWindowListCopyWindowInfo([.optionOnScreenOnly, .excludeDesktopElements], kCGNullWindowID) as? [[String: Any]] else { return nil }
        for window in windows {
            guard (window[kCGWindowOwnerPID as String] as? Int32) == pid,
                  (window[kCGWindowLayer as String] as? Int) == 0,
                  let bounds = window[kCGWindowBounds as String] as? [String: Any],
                  let x = bounds["X"] as? CGFloat, let y = bounds["Y"] as? CGFloat,
                  let w = bounds["Width"] as? CGFloat, let h = bounds["Height"] as? CGFloat,
                  w > 120, h > 200 else { continue }
            return CGRect(x: x, y: y, width: w, height: h)
        }
        return nil
    }

    private func trackMirror(force: Bool = false) {
        guard mode == .attached, let p = panel, let rect = mirrorFrame() else { return }
        if !force, rect == lastTrackedFrame { return }
        lastTrackedFrame = rect
        // CoreGraphics windows use global top-left coordinates; AppKit uses bottom-left coordinates.
        let desktopTop = NSScreen.screens.map { $0.frame.maxY }.max() ?? 0
        let width = p.frame.width
        let x = rect.maxX - width * 0.65
        let y = desktopTop - rect.minY - p.frame.height - 75
        p.setFrameOrigin(NSPoint(x: x, y: y))
    }

    func saveDetachedPosition() {
        guard mode == .detached, let origin = panel?.frame.origin else { return }
        UserDefaults.standard.set(Double(origin.x), forKey: "detachedX")
        UserDefaults.standard.set(Double(origin.y), forKey: "detachedY")
    }
}

struct ControlRow: View {
    var symbol: String
    var title: String
    var shortcut: String
    var action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Image(systemName: symbol).frame(width: 19)
                Text(title).font(.system(size: 12))
                Spacer(minLength: 2)
                Text(shortcut).font(.system(size: 10)).foregroundStyle(.secondary)
            }.contentShape(Rectangle())
        }.buttonStyle(.plain).padding(.horizontal, 10).frame(height: 32)
    }
}

struct FloatingControls: View {
    @ObservedObject var state = MirrorService.shared
    var body: some View {
        VStack(spacing: 0) {
            if state.expanded {
                HStack {
                    Image(systemName: "line.3.horizontal").foregroundStyle(.secondary)
                    Text("镜像助手").font(.system(size: 13, weight: .semibold))
                    Spacer()
                    Button { state.setExpanded(false) } label: { Image(systemName: "minus.circle.fill") }.buttonStyle(.plain)
                }.padding(.horizontal, 10).frame(height: 35)
                Divider().padding(.horizontal, 7)
                ControlRow(symbol: "house", title: "主屏幕", shortcut: "⌘1", action: state.home)
                ControlRow(symbol: "square.stack", title: "App 切换器", shortcut: "⌘2", action: state.switcher)
                ControlRow(symbol: "magnifyingglass", title: "聚焦搜索", shortcut: "⌘3", action: state.spotlight)
                ControlRow(symbol: "plus.magnifyingglass", title: "放大", shortcut: "⌘+", action: state.bigger)
                ControlRow(symbol: "minus.magnifyingglass", title: "缩小", shortcut: "⌘−", action: state.smaller)
                ControlRow(symbol: "arrow.up.left.and.arrow.down.right", title: "实际大小", shortcut: "⌘0", action: state.actualSize)
                Divider().padding(.horizontal, 7)
                ControlRow(symbol: "macwindow", title: "镜像置前", shortcut: "", action: state.bringForward)
                ControlRow(symbol: "arrow.left.arrow.right", title: state.mode == .attached ? "切换到独立模式" : "跟随镜像窗口", shortcut: "", action: state.changeMode)
                if !state.permissionGranted {
                    Button("授权辅助功能") { state.requestPermission() }
                        .font(.system(size: 11)).padding(.top, 5)
                }
                Text(state.message).font(.system(size: 10)).foregroundStyle(.secondary)
                    .lineLimit(1).padding(.horizontal, 8).frame(height: 19)
            } else {
                Button { state.setExpanded(true) } label: {
                    Image(systemName: "iphone.gen3.radiowaves.left.and.right")
                        .font(.system(size: 23, weight: .medium))
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }.buttonStyle(.plain).help("打开镜像悬浮控制器")
            }
        }
        .foregroundStyle(.white)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(.ultraThinMaterial)
        .background(Color(red: 0.17, green: 0.23, blue: 0.53).opacity(0.9))
        .clipShape(RoundedRectangle(cornerRadius: state.expanded ? 15 : 27))
    }
}

final class FloatingPanel: NSPanel, NSWindowDelegate {
    override var canBecomeKey: Bool { false }
    override var canBecomeMain: Bool { false }
    func windowDidMove(_ notification: Notification) { MirrorService.shared.saveDetachedPosition() }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    private var panel: FloatingPanel!
    private var statusItem: NSStatusItem!
    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory)
        let frame = NSRect(x: 700, y: 420, width: 54, height: 54)
        panel = FloatingPanel(contentRect: frame, styleMask: [.borderless, .nonactivatingPanel], backing: .buffered, defer: false)
        panel.level = .floating
        panel.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary]
        panel.isOpaque = false
        panel.backgroundColor = .clear
        panel.hasShadow = true
        panel.isMovableByWindowBackground = true
        panel.delegate = panel
        panel.contentView = NSHostingView(rootView: FloatingControls())
        MirrorService.shared.panel = panel
        panel.orderFrontRegardless()

        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.squareLength)
        statusItem.button?.image = NSImage(systemSymbolName: "iphone", accessibilityDescription: "iPhone 镜像助手")
        let menu = NSMenu()
        menu.addItem(withTitle: "显示悬浮球", action: #selector(showPanel), keyEquivalent: "")
        menu.addItem(withTitle: "切换悬浮模式", action: #selector(changeMode), keyEquivalent: "")
        menu.addItem(withTitle: "授权辅助功能", action: #selector(requestPermission), keyEquivalent: "")
        menu.addItem(.separator())
        menu.addItem(withTitle: "退出", action: #selector(quit), keyEquivalent: "q")
        for item in menu.items { item.target = self }
        statusItem.menu = menu
    }
    @objc private func showPanel() { panel.orderFrontRegardless() }
    @objc private func changeMode() { MirrorService.shared.changeMode() }
    @objc private func requestPermission() { MirrorService.shared.requestPermission() }
    @objc private func quit() { NSApp.terminate(nil) }
}

@main
struct MirrorFloatApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene { Settings { EmptyView() } }
}
